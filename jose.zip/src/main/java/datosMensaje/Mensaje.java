package datosMensaje;

public class Mensaje {
	
	private int id;
	private int idEmisor;
	private int idReceptor; 
	private String mensaje; 
	private String fechaHora; 
	
	
	public Mensaje (int id, int idEmisor, int idReceptor, String mensaje, String fechaHora) {
		this.id = id;
		this.idEmisor = idEmisor;
		this.idReceptor = idReceptor;
		this.mensaje = mensaje;
		this.fechaHora = fechaHora;
	}
	
	public Mensaje (int idEmisor, int idReceptor, String mensaje) {
		this.idEmisor = idEmisor;
		this.idReceptor = idReceptor;
		this.mensaje = mensaje;
	}
	
	public int getId() {
		return this.id;
	}
	
	public int getIdEmisor() {
		return this.idEmisor;
	}
	
	public int getIdReceptor(){
		return this.idReceptor;
	}

	public String getMensaje(){
		return this.mensaje;
	}
	
	public String getFechaHora(){
		return this.fechaHora;
	}
}
