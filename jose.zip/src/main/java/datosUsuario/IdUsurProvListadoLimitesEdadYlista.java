package datosUsuario;

import java.util.List;

public class IdUsurProvListadoLimitesEdadYlista {
	private String id;
	private String provinciaListado;
	private String limiteSuperior;
	private String limiteInferior;
	private List<Usuario3> listaUsuarios;
	
	public IdUsurProvListadoLimitesEdadYlista(String id, String provinciaListado, String limiteSuperior,
			String limiteInferior, List<Usuario3> listaUsuarios) {
		super();
		this.id = id;
		this.provinciaListado = provinciaListado;
		this.limiteSuperior = limiteSuperior;
		this.limiteInferior = limiteInferior;
		this.listaUsuarios = listaUsuarios;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProvinciaListado() {
		return provinciaListado;
	}

	public void setProvinciaListado(String provinciaListado) {
		this.provinciaListado = provinciaListado;
	}

	public String getLimiteSuperior() {
		return limiteSuperior;
	}

	public void setLimiteSuperior(String limiteSuperior) {
		this.limiteSuperior = limiteSuperior;
	}

	public String getLimiteInferior() {
		return limiteInferior;
	}

	public void setLimiteInferior(String limiteInferior) {
		this.limiteInferior = limiteInferior;
	}

	public List<Usuario3> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario3> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

}
