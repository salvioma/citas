package datosUsuario;

import java.util.List;

public class IdUsurProvinciaListadoYlista {
	private String id;
	private String provinciaListado;
	private List<Usuario3> listaUsuarios;
	
	public IdUsurProvinciaListadoYlista(String id, String provinciaListado, List<Usuario3> listaUsuarios) {
		super();
		this.id = id;
		this.provinciaListado = provinciaListado;
		this.listaUsuarios = listaUsuarios;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProvinciaListado() {
		return provinciaListado;
	}

	public void setProvinciaListado(String provinciaListado) {
		this.provinciaListado = provinciaListado;
	}

	public List<Usuario3> getListaUsuarios() {
		return listaUsuarios;
	}

	public void setListaUsuarios(List<Usuario3> listaUsuarios) {
		this.listaUsuarios = listaUsuarios;
	}

}
