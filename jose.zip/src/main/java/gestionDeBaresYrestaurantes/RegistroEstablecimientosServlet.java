package gestionDeBaresYrestaurantes;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosBarRestaurante.BarRestaurante;
import metodosDatasource.MetodosDatasource;

public class RegistroEstablecimientosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public RegistroEstablecimientosServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nombreyemojis = request.getParameter("nombreyemojis");
		String frasepublicitaria = request.getParameter("frasepublicitaria");
		String telefonoydireccion = request.getParameter("telefonoydireccion");
		String foto = request.getParameter("foto");
		BarRestaurante objetoByR = new BarRestaurante(nombreyemojis, frasepublicitaria, telefonoydireccion, foto);
		try {
			MetodosDatasource.addDataByRToDB(objetoByR);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int lastIdBarRestaurante = 0;
		lastIdBarRestaurante = MetodosDatasource.getLastIdBarRestaurante();
		BarRestaurante objetoByRdeDB;
		objetoByRdeDB = MetodosDatasource.getBarRestauranteById(lastIdBarRestaurante);
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("OBJETOBYRDB", objetoByRdeDB);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/confirmacionRegistroEstablecimiento.jsp");
		dispatcher.forward(request, response);	

	}

}
