package inicioSesionYcreacionPerfil;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import metodosDatasource.MetodosDatasource;

public class ConfidenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ConfidenteServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString = request.getParameter("idString");
		String idConfidente = request.getParameter("idConfidente");
		boolean existeIdConfidente = false;
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDSTRING", idString);
		if(idConfidente.equalsIgnoreCase("enEspera")) {
			MetodosDatasource.updateConfidenteEnEspera(idString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/clave.jsp");
			dispatcher.forward(request, response);			
		}else {
			existeIdConfidente = MetodosDatasource.updateConfidente(idString, idConfidente);
			if(existeIdConfidente) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/clave.jsp");
				dispatcher.forward(request, response);
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/confidenteSQLException.jsp");
				dispatcher.forward(request, response);
			}
		}

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/confidenteSQLException.jsp");
        dispatcher.forward(request, response);

	}

}
