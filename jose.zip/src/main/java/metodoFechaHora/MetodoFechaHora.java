package metodoFechaHora;

import java.util.Calendar;

public class MetodoFechaHora {
	
	public static String fechaHoraActual() {
		String fechaHoraActual = "ppqq";
		int anyoActual = 0;
		int mesActual = 0;
		int diaActual = 0;
		int horaActual = 0;
		int minutoActual = 0;
		int segundoActual = 0;

		Calendar cal = Calendar.getInstance();
		anyoActual = cal.get(Calendar.YEAR);
		mesActual = cal.get(Calendar.MONTH);
		diaActual = cal.get(Calendar.DAY_OF_MONTH);
		horaActual = cal.get(Calendar.HOUR_OF_DAY);
		minutoActual = cal.get(Calendar.MINUTE);
		segundoActual = cal.get(Calendar.SECOND);

		fechaHoraActual = anyoActual + "-" + mesActual + "-" + diaActual + " " + horaActual + ":" + minutoActual + ":" + segundoActual;

		return fechaHoraActual;
		
	}
	
	public static String fechaHoraActualBis(String fechaHoraActual) {
		
		String fechaHoraActualVista = "ppqq";
		String stringAnyoMesDia = "ppqq";
		String stringHoraMinutosSegundos = "ppqq";
		String stringAnyo = "ppqq";
		String stringMes = "ppqq";
		String stringDia = "ppqq";
		String stringHora = "ppqq";
		String stringMinuto = "ppqq";
		
		String[] arrayString1 = fechaHoraActual.split(" ");
		stringAnyoMesDia = arrayString1[0];
		stringHoraMinutosSegundos = arrayString1[1];
		
		String[] arrayStringAnyoMesDia = stringAnyoMesDia.split("-");
		stringAnyo = arrayStringAnyoMesDia[0];
		stringMes = arrayStringAnyoMesDia[1];
		stringDia = arrayStringAnyoMesDia[2];
		
		String[] arrayStringHoraMinutosSegundos = stringHoraMinutosSegundos.split(":");
		stringHora = arrayStringHoraMinutosSegundos[0];
		stringMinuto = arrayStringHoraMinutosSegundos[1];
		
		fechaHoraActualVista = stringDia + "/" + stringMes + "/" + stringAnyo + " " + stringHora + ":" + stringMinuto;
		
		return fechaHoraActualVista;
	
	}

}
