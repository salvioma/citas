package chat;

public class DosIdString {
	private String idEscogedor;
	private String idUsuarioEscogido;
	
	public DosIdString(String idEscogedor, String idUsuarioEscogido) {
		super();
		this.idEscogedor = idEscogedor;
		this.idUsuarioEscogido = idUsuarioEscogido;
	}

	public String getIdEscogedor() {
		return idEscogedor;
	}

	public void setIdEscogedor(String idEscogedor) {
		this.idEscogedor = idEscogedor;
	}

	public String getIdUsuarioEscogido() {
		return idUsuarioEscogido;
	}

	public void setIdUsuarioEscogido(String idUsuarioEscogido) {
		this.idUsuarioEscogido = idUsuarioEscogido;
	}

}
