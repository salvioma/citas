package chat;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosMensaje.Mensaje;
import metodosDatasource.MetodosDatasource;

public class EnviarMensajeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public EnviarMensajeServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mensaje = request.getParameter("miMensaje");
		int idUsuarioActual = Integer.valueOf(request.getParameter("actual"));
		int idOtroUsuario = Integer.valueOf(request.getParameter("usuario"));

		Mensaje m = new Mensaje(idUsuarioActual, idOtroUsuario, mensaje);
		
		try {
			MetodosDatasource.addMensajeToDB(m);
			//Como se añade un nuevo mensaje, se vuelve a obtener la lista de mensajes
			List<Mensaje> mensajes = MetodosDatasource.getMensajes(Integer.valueOf(idUsuarioActual), Integer.valueOf(idOtroUsuario));
			
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("LISTA_MENSAJES", mensajes);
			
			RequestDispatcher dispatcher = request.getRequestDispatcher("/chat.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/chat.jsp");
        dispatcher.forward(request, response);
	}


}
