package chat;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosMensaje.Mensaje;
import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class ChatServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ChatServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		HttpSession httpSession = request.getSession();

		String idUsuarioEscogedor = request.getParameter("idEscogedor");
		String idUsuarioEscogido = request.getParameter("idUsuarioEscogido");
		List<Mensaje> mensajes = MetodosDatasource.getMensajes(Integer.valueOf(idUsuarioEscogedor), Integer.valueOf(idUsuarioEscogido));//lista de mensajes (objetos tipo Mensaje) existentes entre el usuario escogedor
																																		//y el usuario escogido. Sabemos que previamente existe un primer mensaje que fué
																																		//introducido en la base de datos en IniciaChatServlet.
		DosIdString dosIdString = new DosIdString(idUsuarioEscogedor, idUsuarioEscogido);

		if(mensajes.isEmpty()) {//redirige al usuario con el que hay match pero todavía no hay chat.
			httpSession.setAttribute("DOSIDSTRING", dosIdString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/usuarioMatchSinMensajes.jsp");
			dispatcher.forward(request, response);
			
		}else {
			Usuario3 usuarioEscogido =  MetodosDatasource.getUsuarioById(idUsuarioEscogido); //Usuario con el que se va a hablar (objeto tipo Usuario3)
			String nombreUsuario = usuarioEscogido.getNombre();//nombre del usuario con el que se va a hablar
			httpSession.setAttribute("NOMBRE_USUARIO", nombreUsuario);//pasamos este dato a chat.jsp
			
			String imagen= usuarioEscogido.getFoto();//foto del usuario con el que se va a hablar
			httpSession.setAttribute("IMAGEN", imagen);//pasamos este dato a chat.jsp
			
			httpSession.setAttribute("LISTA_MENSAJES", mensajes);											
			
			String confidente = mensajes.get(0).getMensaje();//Sacamos el contenido de este primer mensaje y único de momento y lo guardamos en la variable String denominada "confidente".
											//El contenido de este mensaje va a ser diferente dependiente de características del usuario escogedor; si es hombre hetero, o bien si es mujer hetero que quiere iniciar chat directamente con el chico sin recurirr a su confidente o es gay o lesbiana (esto está determinado en IniciaChatServlet).
			//Creamos a vacío un array de String con dos celdas preparado para que el chico hetero inicie comunicación con el confidente de la chica (en los demás casos no se va a emplear este array).
			String[] listaIds = new String[2]; //array con sólo dos posiciones: 0 --> idConfidente, 1 --> idChica
			String idChica = null;
			Usuario3 usuarioChica = null;
	
			if (confidente.contains(",")) { //Si chico hetero va a hablar (y tiene que ser con el confidente de la chica) entonces el contenido del mensaje contiene "," en los demás casos no.
				listaIds = confidente.split(",");//divide al String que hemos llamado "confidente" en dos trozos (que están separados por la coma) y los introduce en las celdas del array listaIds.
				confidente = listaIds[0];//contenido de la primera celda del array listaIds que corresponde con el id del confidente de la chica. El contenido de esta celda lo guardamos en la variable String ya inicializada "confidente", con lo que actualizamos el valor de esta variable que queda ahora sólo con el id del confidente.
				idChica = listaIds[1];//contenido de la segunda celda del array listaIds, que corresponde con el id de la chica, y que cargamos en la variable String denominada "idChica".
				usuarioChica = MetodosDatasource.getUsuarioById(idChica);//sacamos el objeto Usuario3 que corresponde con la chica escogida por el hombre hetero.
			}
	
			httpSession.setAttribute("CONFIDENTE", confidente);//es el identificador, en String, del confidente de la chica (que era el contenido de la primera celda del array listaIds) si el escogedor es hombre hetero, si no lo es el String sería "NOCONFIDENTE".
			httpSession.setAttribute("USUARIO_CHICA", usuarioChica);//es un objeto tipo Usuario3 que corresponde con la chica escogida por el hombre hetero, si el escogedor no es un hombre hetero entonces esta variable/objeto tendría el valor de null. 
			httpSession.setAttribute("DOSIDSTRING", dosIdString);
	
			RequestDispatcher dispatcher = request.getRequestDispatcher("/chat.jsp");
			dispatcher.forward(request, response);
		}

	}

}
