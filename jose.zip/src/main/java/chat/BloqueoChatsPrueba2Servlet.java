package chat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class BloqueoChatsPrueba2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BloqueoChatsPrueba2Servlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idUsuarioIniciaSesion = request.getParameter("idUsuarioIniciaSesion");
		String idParaBloquear = request.getParameter("idParaBloquear");
		int idUsuarioIniciaSesionInt = Integer.parseInt(idUsuarioIniciaSesion);
		List<Usuario3> listaUsuariosChateo = new ArrayList<Usuario3>();
		List<Usuario3> listaUsuariosChateoSinBloq = new ArrayList<Usuario3>();
		listaUsuariosChateo = MetodosDatasource.getListaUsuariosChateo(idUsuarioIniciaSesionInt);
		for(Usuario3 usuario : listaUsuariosChateo) {
			if(!String.valueOf(usuario.getId()).equalsIgnoreCase(idParaBloquear)) {
				listaUsuariosChateoSinBloq.add(usuario);
			}
		}
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDUSUARIOINICIASESION", idUsuarioIniciaSesion);
		httpSession.setAttribute("LISTAUSUARIOSCHATEOSINBLOQ", listaUsuariosChateoSinBloq);	
		RequestDispatcher dispatcher = request.getRequestDispatcher("/listadoDeChatsConBloqueoChatPrueba.jsp");
        dispatcher.forward(request, response);

	}

}
