package inicioSesionConPerfilYaCreado;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import metodosDatasource.MetodosDatasource;

public class PosponerConfidenteOnoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public PosponerConfidenteOnoServlet() {
        super();
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString = request.getParameter("idString");
		String idConfidente = request.getParameter("idConfidente");
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDUSUARIO", idString);
		if(idConfidente.equals("enEspera")) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/actualizaObusca.jsp");
			dispatcher.forward(request, response);
		}else {
			boolean existeIdConfidente = false;		
			existeIdConfidente = MetodosDatasource.updateConfidente(idString, idConfidente);
			if(existeIdConfidente) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/actualizaObusca.jsp");
				dispatcher.forward(request, response);
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/avisoDeConfidenteSQLException.jsp");
				dispatcher.forward(request, response);
			}
		}
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/avisoDeConfidenteSQLException.jsp");
        dispatcher.forward(request, response);
	}

}
