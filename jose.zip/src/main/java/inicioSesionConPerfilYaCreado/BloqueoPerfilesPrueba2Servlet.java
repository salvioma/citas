package inicioSesionConPerfilYaCreado;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class BloqueoPerfilesPrueba2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BloqueoPerfilesPrueba2Servlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idUsuarioIniciaSesion = request.getParameter("idUsuarioIniciaSesion");
		String idParaBloquear = request.getParameter("idParaBloquear");
		List<Usuario3> listaUsuariosMatch = new ArrayList<Usuario3>();
		List<Usuario3> listaUsuariosMatchSinBloq = new ArrayList<Usuario3>();
		listaUsuariosMatch = MetodosDatasource.buscaMatchesDeUsuario(idUsuarioIniciaSesion);
		for(Usuario3 usuario : listaUsuariosMatch) {
			if(!String.valueOf(usuario.getId()).equalsIgnoreCase(idParaBloquear)) {
				listaUsuariosMatchSinBloq.add(usuario);
			}
		}
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDUSUARIOINICIASESION", idUsuarioIniciaSesion);
		httpSession.setAttribute("LISTAUSUARIOSMATCHSINBLOQ", listaUsuariosMatchSinBloq);	
		RequestDispatcher dispatcher = request.getRequestDispatcher("/listadoDeMatchesConBloqueoPefilPrueba.jsp");
        dispatcher.forward(request, response);

	}

}
