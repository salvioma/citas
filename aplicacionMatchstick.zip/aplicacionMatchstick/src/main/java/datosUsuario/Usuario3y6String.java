package datosUsuario;

public class Usuario3y6String {
	private Usuario3 usuarioEscogido;
	private String mensajeMatch;
	private String idEscogedor;
	private String idEscogido;
	private String limiteSuperior;
	private String limiteInferior;
	private String provincia;
	
	public Usuario3y6String(Usuario3 usuarioEscogido, String mensajeMatch, String idEscogedor, String idEscogido,
			String limiteSuperior, String limiteInferior, String provincia) {
		super();
		this.usuarioEscogido = usuarioEscogido;
		this.mensajeMatch = mensajeMatch;
		this.idEscogedor = idEscogedor;
		this.idEscogido = idEscogido;
		this.limiteSuperior = limiteSuperior;
		this.limiteInferior = limiteInferior;
		this.provincia = provincia;
	}

	public Usuario3 getUsuarioEscogido() {
		return usuarioEscogido;
	}

	public void setUsuarioEscogido(Usuario3 usuarioEscogido) {
		this.usuarioEscogido = usuarioEscogido;
	}

	public String getMensajeMatch() {
		return mensajeMatch;
	}

	public void setMensajeMatch(String mensajeMatch) {
		this.mensajeMatch = mensajeMatch;
	}

	public String getIdEscogedor() {
		return idEscogedor;
	}

	public void setIdEscogedor(String idEscogedor) {
		this.idEscogedor = idEscogedor;
	}

	public String getIdEscogido() {
		return idEscogido;
	}

	public void setIdEscogido(String idEscogido) {
		this.idEscogido = idEscogido;
	}

	public String getLimiteSuperior() {
		return limiteSuperior;
	}

	public void setLimiteSuperior(String limiteSuperior) {
		this.limiteSuperior = limiteSuperior;
	}

	public String getLimiteInferior() {
		return limiteInferior;
	}

	public void setLimiteInferior(String limiteInferior) {
		this.limiteInferior = limiteInferior;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

}
