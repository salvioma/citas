package datosUsuario;

public class Usuario3 {
	private int id;
	private String busca;
	private String sexo;
	private String nombre;
	private String fechanacimiento;
	private String provincia;
	private String localidad;
	private String foto;
	private String autodescripcion;
	private String megusta;
	private String confidente;
	private String clave;
	
	public Usuario3(int id, String busca, String sexo, String nombre, String fechanacimiento, String provincia,
			String localidad, String foto, String autodescripcion, String megusta, String confidente, String clave) {
		super();
		this.id = id;
		this.busca = busca;
		this.sexo = sexo;
		this.nombre = nombre;
		this.fechanacimiento = fechanacimiento;
		this.provincia = provincia;
		this.localidad = localidad;
		this.foto = foto;
		this.autodescripcion = autodescripcion;
		this.megusta = megusta;
		this.confidente = confidente;
		this.clave = clave;
	}

	public Usuario3(int id, String busca, String sexo, String nombre, String fechanacimiento, String provincia,
			String localidad, String foto, String autodescripcion, String megusta, String confidente) {
		super();
		this.id = id;
		this.busca = busca;
		this.sexo = sexo;
		this.nombre = nombre;
		this.fechanacimiento = fechanacimiento;
		this.provincia = provincia;
		this.localidad = localidad;
		this.foto = foto;
		this.autodescripcion = autodescripcion;
		this.megusta = megusta;
		this.confidente = confidente;
	}

	public Usuario3(String busca, String sexo, String nombre, String fechanacimiento, String provincia,
			String localidad, String foto, String autodescripcion, String megusta, String confidente, String clave) {
		super();
		this.busca = busca;
		this.sexo = sexo;
		this.nombre = nombre;
		this.fechanacimiento = fechanacimiento;
		this.provincia = provincia;
		this.localidad = localidad;
		this.foto = foto;
		this.autodescripcion = autodescripcion;
		this.megusta = megusta;
		this.confidente = confidente;
		this.clave = clave;
	}
	
	public Usuario3 (int id, String nombre, String foto) {
		this.id=id;
		this.nombre = nombre;
		this.foto = foto;
	}
	
	public Usuario3(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public String getBusca() {
		return busca;
	}

	public void setBusca(String busca) {
		this.busca = busca;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getFechanacimiento() {
		return fechanacimiento;
	}

	public void setFechanacimiento(String fechanacimiento) {
		this.fechanacimiento = fechanacimiento;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getAutodescripcion() {
		return autodescripcion;
	}

	public void setAutodescripcion(String autodescripcion) {
		this.autodescripcion = autodescripcion;
	}

	public String getMegusta() {
		return megusta;
	}

	public void setMegusta(String megusta) {
		this.megusta = megusta;
	}

	public String getConfidente() {
		return confidente;
	}

	public void setConfidente(String confidente) {
		this.confidente = confidente;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}
	

}
