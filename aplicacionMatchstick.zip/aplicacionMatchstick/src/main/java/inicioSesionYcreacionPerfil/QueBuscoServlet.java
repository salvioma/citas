package inicioSesionYcreacionPerfil;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class QueBuscoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public QueBuscoServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String queBusco = request.getParameter("queBusco");
		Usuario3 objetoUsuario = new Usuario3(queBusco, null, null, null, null, null, null, null, "a", "noConfid", "55abc");
		MetodosDatasource.makeJDBCConnection();
		try {
			MetodosDatasource.addDataToDB(objetoUsuario);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		int idObjeto = MetodosDatasource.getLastId();
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDOBJETO", idObjeto);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/eresHombreOmujer.jsp");
		dispatcher.forward(request, response);				

	}


}
