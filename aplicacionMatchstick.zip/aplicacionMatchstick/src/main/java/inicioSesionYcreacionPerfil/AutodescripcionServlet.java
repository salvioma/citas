package inicioSesionYcreacionPerfil;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import metodosDatasource.MetodosDatasource;

public class AutodescripcionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public AutodescripcionServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString = request.getParameter("idString");
		String autodescripcion = request.getParameter("autodescripcion");
		boolean numCaractCorrecto = false;
		HttpSession httpSesion = request.getSession();
		httpSesion.setAttribute("IDSTRING", idString);
		numCaractCorrecto = MetodosDatasource.updateAutodescripcion(idString, autodescripcion);
		if(numCaractCorrecto) {
			if(MetodosDatasource.getUsuarioById(idString).getBusca().equalsIgnoreCase("hombre") && MetodosDatasource.getUsuarioById(idString).getSexo().equalsIgnoreCase("mujer")) {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/confidente.jsp");
				dispatcher.forward(request, response);
			}else {
				RequestDispatcher dispatcher = request.getRequestDispatcher("/clave.jsp");
				dispatcher.forward(request, response);
				
			}
		}else {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/autodescripcionSQLException.jsp");
			dispatcher.forward(request, response);			
		}

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/autodescripcionSQLException.jsp");
        dispatcher.forward(request, response);

	}

}
