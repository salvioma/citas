package metodosAuxiliares;

import java.util.Calendar;

import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class MetodosAuxiliares {
	public static int metodoCalcularEdad2(Usuario3 usuario) {
		int edad = 0;
		int anyoNacimiento = 0;
		int mesNacimiento = 0;
		int diaNacimiento = 0;
		int anyoHoy = 0;
		int mesHoy = 0;
		int diaHoy = 0;
		if(usuario.getFechanacimiento() == null) {
			return 0;
		}else {
			String[] arrayString = usuario.getFechanacimiento().split("-");
			anyoNacimiento = Integer.parseInt(arrayString[0]);
			mesNacimiento = Integer.parseInt(arrayString[1]);
			diaNacimiento = Integer.parseInt(arrayString[2]);		
			Calendar cal = Calendar.getInstance();
			anyoHoy = cal.get(Calendar.YEAR);
			mesHoy = cal.get(Calendar.MONTH) + 1;//Calendar.MONTH devuelve valores del 0 al 11, ya que enero lo empieza con 0, por ello hay que sumarle 1.
			diaHoy = cal.get(Calendar.DAY_OF_MONTH);
			if(diaHoy<diaNacimiento) {
				diaHoy = diaHoy + 30;
				mesNacimiento = mesNacimiento + 1;		
			}
			if(mesHoy<mesNacimiento) {
					mesHoy = mesHoy + 12;
					anyoNacimiento = anyoNacimiento + 1;
				}
			edad = anyoHoy - anyoNacimiento;
				
			return edad;
		}
	}
	
	public static boolean metodoMatch( String idEscogedor, String idEscogido) {//Este método nos dice si está presente en la lista de megusta del usuarioUno el identificador del UsuarioDos,
		boolean match = false;//y su vez, si en la lista de megusta del usuarioDos está presente el identificador del usuarioUno.
		boolean presenciaEnEscogedor = false;//Si es true, idDos está presente en la "lista" del usuarioUno.
		boolean presenciaEnEscogido = false;//Si es true, idUno está presente en la "lista" del usuarioDos.
		MetodosDatasource.makeJDBCConnection();
		String LosMegustaIdEscogedor = MetodosDatasource.getUsuarioById(idEscogedor).getMegusta();//Esta es la "lista" de los megusta del usuarioUno.
		presenciaEnEscogedor = LosMegustaIdEscogedor.contains(idEscogido);//La devolución de este método nos dice si el identificador del usuarioDos está presente en la "lista" del usuarioUno.
		String LosMegustaIdEscogido = MetodosDatasource.getUsuarioById(idEscogido).getMegusta();//Esta es la "lista" de los megusta del usuarioDos.
		presenciaEnEscogido = LosMegustaIdEscogido.contains(idEscogedor);//La devolución de este método nos dice si el identificador del usuarioUno está presente en la "lista" del usuarioDos.
		if(presenciaEnEscogedor && presenciaEnEscogido) {match = true;}//Si se dan ambas presencias entonces hay MATCH.
		return match;
	}
	
	public static boolean numberFormatExceptionLimitesEdades(String limiteSuperior, String limiteInferior) {
		boolean datosCorrectos = false;
		int limiteSup = 0;
		int limiteInf = 0;
		try {
			limiteSup = Integer.parseInt(limiteSuperior);
			limiteInf = Integer.parseInt(limiteInferior);
		} catch (NumberFormatException e) {
			return datosCorrectos;
		}
		if(limiteSup < limiteInf) {
			return datosCorrectos;
		}else {
			datosCorrectos = true;
			return datosCorrectos;
		}
	}

}
