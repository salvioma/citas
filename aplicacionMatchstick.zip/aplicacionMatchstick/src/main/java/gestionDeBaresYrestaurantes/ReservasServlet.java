package gestionDeBaresYrestaurantes;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosBarRestaurante.BarRestaurante;
import metodosDatasource.MetodosDatasource;

public class ReservasServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ReservasServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idBarRestaurante = request.getParameter("idBarRestaurante");
		int idBarRestauranteInt = Integer.parseInt(idBarRestaurante);
		BarRestaurante barRestaurante = MetodosDatasource.getBarRestauranteById(idBarRestauranteInt);
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("BARRESTAURANTE", barRestaurante);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/reservaBarRestaurante.jsp");
		dispatcher.forward(request, response);	

	}

}
