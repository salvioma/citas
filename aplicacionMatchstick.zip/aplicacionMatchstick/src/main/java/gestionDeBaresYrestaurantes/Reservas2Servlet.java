package gestionDeBaresYrestaurantes;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosBarRestaurante.BarRestaurante;
import metodosDatasource.MetodosDatasource;


public class Reservas2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Reservas2Servlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idBarRestaurante = request.getParameter("idBarRestaurante");
		String dia = request.getParameter("dia");
		String hora = request.getParameter("hora");
		String nombreReserva = getInitParameter("nombreReserva");
		int idBarRestauranteInt = Integer.parseInt(idBarRestaurante);
		BarRestaurante barRestaurante = MetodosDatasource.getBarRestauranteById(idBarRestauranteInt);
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("BARRESTAURANTE", barRestaurante);
		httpSession.setAttribute("DIA", dia);
		httpSession.setAttribute("HORA", hora);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/confirmacionReserva.jsp");
		dispatcher.forward(request, response);				

	}

}
