package pasoAbusquedaDePerfilesOactualizacionDePerfil;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.Usuario3;
import datosUsuario.Usuario3y4String;
import metodosAuxiliares.MetodosAuxiliares;
import metodosDatasource.MetodosDatasource;

public class MatchOnoMatchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public MatchOnoMatchServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String mensaje = null;
		Usuario3y4String usuarioEscogidoY4String = null;
		String idEscogedor = request.getParameter("idEscogedor");
		String idEscogido = request.getParameter("idEscogido");
		String provincia = request.getParameter("provincia");
		MetodosDatasource.updateMeGusta(idEscogedor, idEscogido);
		Usuario3 usuarioEscogido = MetodosDatasource.getUsuarioById(idEscogido);
		if(MetodosAuxiliares.metodoMatch(idEscogedor, idEscogido) &&
				MetodosDatasource.getUsuarioById(idEscogido).getBusca().equalsIgnoreCase("hombre") && MetodosDatasource.getUsuarioById(idEscogido).getSexo().equalsIgnoreCase("mujer") &&
				MetodosDatasource.getUsuarioById(idEscogido).getConfidente().equalsIgnoreCase("enEspera")) {
						mensaje = "La chica que te gusta todavía no ha elegido confidente. Tu comunicación que se inicia mediante el chateo con su confidente queda por tanto en espera. Para saberlo podrás consutar su perfil en tus matches.";
						usuarioEscogidoY4String = new Usuario3y4String(usuarioEscogido, mensaje, idEscogedor, idEscogido, provincia);
						HttpSession httpSession = request.getSession();
						httpSession.setAttribute("USUARIOESCOGIDOY4STRING", usuarioEscogidoY4String);
				        RequestDispatcher dispatcher = request.getRequestDispatcher("/perfilEscogidoConMatchConConfidenteEnEspera.jsp");
				        dispatcher.forward(request, response);
		}else if(MetodosAuxiliares.metodoMatch(idEscogedor, idEscogido) &&
					MetodosDatasource.getUsuarioById(idEscogido).getBusca().equalsIgnoreCase("hombre") && MetodosDatasource.getUsuarioById(idEscogido).getSexo().equalsIgnoreCase("mujer") &&
					!MetodosDatasource.getUsuarioById(idEscogido).getConfidente().equalsIgnoreCase("enEspera")){
						mensaje = "A esta persona tú también le gustas. Si quieres puedes iniciar chat con su confidente. Este confidente es quien aconsejará a la persona que te interesa sobre la posibilidad de iniciar una relación, en este caso contigo.";
						usuarioEscogidoY4String = new Usuario3y4String(usuarioEscogido, mensaje, idEscogedor, idEscogido, provincia);
						HttpSession httpSession = request.getSession();
						httpSession.setAttribute("USUARIOESCOGIDOY4STRING", usuarioEscogidoY4String);
				        RequestDispatcher dispatcher = request.getRequestDispatcher("/perfilEscogidoConMatch.jsp");
				        dispatcher.forward(request, response);

		}else if(MetodosAuxiliares.metodoMatch(idEscogedor, idEscogido)) {
						mensaje = "A esta persona tú también le gustas. Si quieres puedes iniciar chat con esta persona";
						usuarioEscogidoY4String = new Usuario3y4String(usuarioEscogido, mensaje, idEscogedor, idEscogido, provincia);
						HttpSession httpSession = request.getSession();
						httpSession.setAttribute("USUARIOESCOGIDOY4STRING", usuarioEscogidoY4String);
				        RequestDispatcher dispatcher = request.getRequestDispatcher("/perfilEscogidoConMatch.jsp");
				        dispatcher.forward(request, response);
		}else {
						mensaje = "Tu preferencia por este perfil ha quedado registrada.";
						usuarioEscogidoY4String = new Usuario3y4String(usuarioEscogido, mensaje, idEscogedor, idEscogido, provincia);
						HttpSession httpSession = request.getSession();
						httpSession.setAttribute("USUARIOESCOGIDOY4STRING", usuarioEscogidoY4String);
				        RequestDispatcher dispatcher = request.getRequestDispatcher("/perfilEscogidoSinMatch.jsp");
				        dispatcher.forward(request, response);
		}

	}

}
