package pasoAbusquedaDePerfilesOactualizacionDePerfil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class ListadoMatchesServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListadoMatchesServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idUsuarioIniciaSesion = request.getParameter("idString");
		List<Usuario3> listaUsuariosMatch = new ArrayList<Usuario3>();
		listaUsuariosMatch = MetodosDatasource.buscaMatchesDeUsuario(idUsuarioIniciaSesion);
		HttpSession httpSession = request.getSession();
		httpSession.setAttribute("IDUSUARIOINICIASESION", idUsuarioIniciaSesion);
		httpSession.setAttribute("LISTAUSUARIOSMATCH", listaUsuariosMatch);		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/listadoDeMatches.jsp");
        dispatcher.forward(request, response);

	}

}
