package pasoAbusquedaDePerfilesOactualizacionDePerfil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.IdUsurProvListadoLimitesEdadYlista;
import datosUsuario.Usuario3;
import metodosAuxiliares.MetodosAuxiliares;
import metodosDatasource.MetodosDatasource;

public class ListaUsuariosPorEdadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListaUsuariosPorEdadServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IdUsurProvListadoLimitesEdadYlista idUsurProvListadoLimitesEdadYlista = null;
		List<Usuario3> listaUsuariosPorEdad = new ArrayList<Usuario3>();
		List<Usuario3> listaUsuariosPorEdadYprovincia = new ArrayList<Usuario3>();
		int limiteSup = 0;
		int limiteInf = 0;
		String idString = request.getParameter("idString");
		String limiteSuperior = request.getParameter("limiteSuperior");
		String limiteInferior = request.getParameter("limiteInferior");
		String provincia = request.getParameter("provincia");
		if(MetodosAuxiliares.numberFormatExceptionLimitesEdades(limiteSuperior, limiteInferior)) {
				limiteSup = Integer.parseInt(limiteSuperior);
				limiteInf = Integer.parseInt(limiteInferior);
				if(MetodosDatasource.getUsuarioById(idString).getSexo().equalsIgnoreCase("hombre") && MetodosDatasource.getUsuarioById(idString).getBusca().equalsIgnoreCase("hombre")) {
					listaUsuariosPorEdad = MetodosDatasource.getUsuariosHombreBuscaHombreByEdad(limiteSup, limiteInf, Integer.valueOf(idString));
					for(Usuario3 usuario : listaUsuariosPorEdad) {
						if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorEdadYprovincia.add(usuario);}
					}
				}else if(MetodosDatasource.getUsuarioById(idString).getSexo().equalsIgnoreCase("mujer") && MetodosDatasource.getUsuarioById(idString).getBusca().equalsIgnoreCase("hombre")) {
					listaUsuariosPorEdad = MetodosDatasource.getUsuariosHombreBuscaMujerByEdad(limiteSup, limiteInf, Integer.valueOf(idString));
					for(Usuario3 usuario : listaUsuariosPorEdad) {
						if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorEdadYprovincia.add(usuario);}
					}
				}else if(MetodosDatasource.getUsuarioById(idString).getSexo().equalsIgnoreCase("hombre") && MetodosDatasource.getUsuarioById(idString).getBusca().equalsIgnoreCase("mujer")) {
					listaUsuariosPorEdad = MetodosDatasource.getUsuariosMujerBuscaHombreByEdad(limiteSup, limiteInf, Integer.valueOf(idString));
					for(Usuario3 usuario : listaUsuariosPorEdad) {
						if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorEdadYprovincia.add(usuario);}
					}					
				}else if(MetodosDatasource.getUsuarioById(idString).getSexo().equalsIgnoreCase("mujer") && MetodosDatasource.getUsuarioById(idString).getBusca().equalsIgnoreCase("mujer")) {
					listaUsuariosPorEdad = MetodosDatasource.getUsuariosMujerBuscaMujerByEdad(limiteSup, limiteInf, Integer.valueOf(idString));
					for(Usuario3 usuario : listaUsuariosPorEdad) {
						if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorEdadYprovincia.add(usuario);}
					}					
				}else {}
				idUsurProvListadoLimitesEdadYlista = new IdUsurProvListadoLimitesEdadYlista(idString, provincia, limiteSuperior, limiteInferior, listaUsuariosPorEdadYprovincia);
				HttpSession httpSession = request.getSession();
				httpSession.setAttribute("IDUSURPROVLISTADOLIMITESEDADYLISTA", idUsurProvListadoLimitesEdadYlista);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/resultadoListaUsuariosPorEdad.jsp");
				dispatcher.forward(request, response);
		}else {
			HttpSession httpSesion = request.getSession();
			httpSesion.setAttribute("IDSTRING", idString);
			httpSesion.setAttribute("PROVINCIA", provincia);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/filtroEdadNumberFormatException.jsp");
			dispatcher.forward(request, response);
		}		

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/filtroEdadNumberFormatException.jsp");
		dispatcher.forward(request, response);

	}

}
