package pasoAbusquedaDePerfilesOactualizacionDePerfil;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.IdUsurProvinciaListadoYlista;
import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class BusquedaDePerfilesDeUsuariosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public BusquedaDePerfilesDeUsuariosServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idUsuarioIniciaSesion = request.getParameter("idString");
		String provincia = request.getParameter("provincia");
		List<Usuario3> listaUsuarios = new ArrayList<Usuario3>();
		List<Usuario3> listaUsuariosPorProvincia = new ArrayList<Usuario3>();
		IdUsurProvinciaListadoYlista idUsurProvListadoYlista = null;
		Usuario3 usuarioIniciaSesion = MetodosDatasource.getUsuarioById(idUsuarioIniciaSesion);		
		if(usuarioIniciaSesion.getBusca().equals("hombre")) {
			if(usuarioIniciaSesion.getSexo().equals("mujer")){
				listaUsuarios = MetodosDatasource.getUsuariosHombreBuscaMujer(Integer.valueOf(idUsuarioIniciaSesion));
				for(Usuario3 usuario : listaUsuarios) {
					if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorProvincia.add(usuario);}
				}

			}else{
				listaUsuarios = MetodosDatasource.getUsuariosHombreBuscaHombre(Integer.valueOf(idUsuarioIniciaSesion));
				for(Usuario3 usuario : listaUsuarios) {
					if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorProvincia.add(usuario);}
				}
			}			
		}else {
			if(usuarioIniciaSesion.getSexo().equals("mujer")){
				listaUsuarios = MetodosDatasource.getUsuariosMujerBuscaMujer(Integer.valueOf(idUsuarioIniciaSesion));
				for(Usuario3 usuario : listaUsuarios) {
					if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorProvincia.add(usuario);}
				}
			}else{
				listaUsuarios = MetodosDatasource.getUsuariosMujerBuscaHombre(Integer.valueOf(idUsuarioIniciaSesion));
				for(Usuario3 usuario : listaUsuarios) {
					if(usuario.getProvincia().equalsIgnoreCase(provincia)) {listaUsuariosPorProvincia.add(usuario);}
				}
			}
		}			
		HttpSession httpSession = request.getSession();
		idUsurProvListadoYlista = new IdUsurProvinciaListadoYlista(idUsuarioIniciaSesion, provincia, listaUsuariosPorProvincia);
		httpSession.setAttribute("IDUSURPROVLISTADOYLISTAUSUARIOS", idUsurProvListadoYlista);		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/perfilesDeUsuarios.jsp");
        dispatcher.forward(request, response);

	}


}
