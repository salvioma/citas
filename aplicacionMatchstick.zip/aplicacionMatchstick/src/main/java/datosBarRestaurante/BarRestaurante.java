package datosBarRestaurante;

public class BarRestaurante {
	private int id;
	private String nombreyemojis;
	private String frasepublicitaria;
	private String telefonoydireccion;
	private String foto;
	
	public BarRestaurante(int id, String nombreyemojis, String frasepublicitaria, String telefonoydireccion,
			String foto) {
		super();
		this.id = id;
		this.nombreyemojis = nombreyemojis;
		this.frasepublicitaria = frasepublicitaria;
		this.telefonoydireccion = telefonoydireccion;
		this.foto = foto;
	}

	public BarRestaurante(String nombreyemojis, String frasepublicitaria, String telefonoydireccion, String foto) {
		super();
		this.nombreyemojis = nombreyemojis;
		this.frasepublicitaria = frasepublicitaria;
		this.telefonoydireccion = telefonoydireccion;
		this.foto = foto;
	}

	public int getId() {
		return id;
	}

	public String getNombreyemojis() {
		return nombreyemojis;
	}

	public void setNombreyemojis(String nombreyemojis) {
		this.nombreyemojis = nombreyemojis;
	}

	public String getFrasepublicitaria() {
		return frasepublicitaria;
	}

	public void setFrasepublicitaria(String frasepublicitaria) {
		this.frasepublicitaria = frasepublicitaria;
	}

	public String getTelefonoydireccion() {
		return telefonoydireccion;
	}

	public void setTelefonoydireccion(String telefonoydireccion) {
		this.telefonoydireccion = telefonoydireccion;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

}
