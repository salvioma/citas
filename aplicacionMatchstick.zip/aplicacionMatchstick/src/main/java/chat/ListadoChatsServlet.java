package chat;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class ListadoChatsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ListadoChatsServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession httpSession = request.getSession();

		String idUsuarioIniciaSesion = (String) httpSession.getAttribute("IDUSUARIO");
		
		List<Usuario3> usuariosChat = MetodosDatasource.getListaUsuariosChateo(Integer.valueOf(idUsuarioIniciaSesion));
		httpSession.setAttribute("USUARIOS_CHAT", usuariosChat);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/listadoDeChats.jsp");
		dispatcher.forward(request, response);

	}

}
