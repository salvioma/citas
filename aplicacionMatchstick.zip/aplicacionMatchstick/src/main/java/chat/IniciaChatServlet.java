package chat;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import datosMensaje.Mensaje;
import datosUsuario.Usuario3;
import metodosDatasource.MetodosDatasource;

public class IniciaChatServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public IniciaChatServlet() {
        super();
    }

    /*
     * Ocurre cuando se pulsa sobre "Iniciar chat ahora", "Inciar chat" o "Iniciar chat con confidente" al hacer match,
     * esta última opción (Iniciar chat con confidente) es para hombres hetero que quieren empezar chat (lo tienen que hacer con el confidente de la chica).
     * Redirige el flujo de datos a la clase ChatServlet (de clase servlet a clase servlet).
     * 
     * VARIABLES
     * idUsuarioEscogedor --> siempre es el que pulsa sobre "me gusta" el último
     * idUsuarioEscogido --> persona con la que se ha hecho match ó confidente de la chica en caso de que el idEscogedor pertenezca a un chico hetero
     * idConfidente --> sólo utilizado cuando el escogedor es chica hetero y quiere que el chico que le gusta primero hable con su confidente, aunque
     * 					en este caso el flujo de datos irá a NuevoChatServlet y no a IniciaChatServlet
     * idChica --> sólo utilizado cuando el escogedor es chico hetero, para saber de quién es el confidente
     * 
     * Cuando una chica hetero es el escogedor, elige si hablar directamente con el chico o que el chico hable con su confidente
     * 	--> Si elige que el chico hable con el confidente --> se introducirá en la base de datos, en la tabla "mensajes", un mensaje con el id del confidente,
     * 		aunque en este caso el flujo de datos irá para NuevoChatServlet y no para InciciaChatServlet
     * 	--> Si elige que hablar directamente con el chico --> se introducirá en la base de datos en la tabla "mensajes" el mensaje "NOCONFIDENTE" 
     * 
     * Cuando un chico hetero es el escogedor, sólo tiene la opción de hablar con el confidente de la chica --> se introducirá un mensaje con el id del confidente
     * 	--> En este caso, idEscogido es el id del confidente de la chica
     * 
     * En cualquier otro caso, se introduce "NOCONFIDENTE"
     * 
     * El primer mensaje (el id del confidente o "NOCONFIDENTE") nunca se mostrará en el chat, sirve para distinguir si se está hablando
     * con un confidente o no, o para saber si en la conversación eres tú el confidente (y que aparezca la opción de autorizar al chico para
     * que hable con la chica).
     * 
    */

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idUsuarioEscogedor = request.getParameter("idEscogedor");
		String idUsuarioEscogido = request.getParameter("idEscogido");//si el usuario escogedor es hombre hetero el idUsuarioEscogido corresponde con el confidente de la chica
		
		if (!MetodosDatasource.existeChat(Integer.valueOf(idUsuarioEscogedor), Integer.valueOf(idUsuarioEscogido))) {//Si no existe chat previo entre usuario escogedor y usuario escogido
			Usuario3 usuarioEscogedor = MetodosDatasource.getUsuarioById2(Integer.valueOf(idUsuarioEscogedor));
			Mensaje m;
			
			if (usuarioEscogedor.getSexo().equals("hombre") && usuarioEscogedor.getBusca().equals("mujer")) {//Si el usuarioEscogedor es hombre hetero
				String primerMensaje = idUsuarioEscogido + "," + request.getParameter("idChica");//el idUsuarioEscogido en este caso es el confidente de la chica
				m = new Mensaje(Integer.valueOf(idUsuarioEscogido), Integer.valueOf(idUsuarioEscogedor), primerMensaje);//el contenido del primer mensaje contiene el identificador del confidente
				try {																				//de la chica (idUsuarioEscogido) y el identificador de la chica (idChica).
					MetodosDatasource.addMensajeToDB(m);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else {//Si el usuarioEscogedor es mujer hetero que quiere iniciar chat con el chico sin recurrir a su confidente o bien es gay o lesbiana
				m = new Mensaje(Integer.valueOf(idUsuarioEscogido), Integer.valueOf(idUsuarioEscogedor), "NOCONFIDENTE");//en este caso el contenido del primer mensaje contiene las letras
				try {																									// "NOCONFIDENTE"
					MetodosDatasource.addMensajeToDB(m);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}//después de ejecutarse las líneas de código anteriores ya existe algún mensaje entre el usuario escogedor y el escogido (registrado en la base de datos por el método addMensajeToDB)		
	
		RequestDispatcher dispatcher = request.getRequestDispatcher("/ChatServlet?idEscogedor="+ idUsuarioEscogedor + "&idUsuarioEscogido=" + idUsuarioEscogido);
		dispatcher.forward(request, response);

	}

}
