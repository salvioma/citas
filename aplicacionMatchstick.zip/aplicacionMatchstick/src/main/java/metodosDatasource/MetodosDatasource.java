package metodosDatasource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import datosBarRestaurante.BarRestaurante;
import datosMensaje.Mensaje;
import datosUsuario.Usuario3;
import metodosAuxiliares.MetodosAuxiliares;

public class MetodosDatasource {
	private static PreparedStatement stm = null;
	private  static Connection conn = null;
	
	public static void makeJDBCConnection() {

		try {
			Class.forName("com.mysql.jdbc.Driver");			
		} catch (ClassNotFoundException e) {			
			e.printStackTrace();
			return;
		}

		try {
			// DriverManager: The basic service for managing a set of JDBC drivers.
			conn = DriverManager.getConnection("jdbc:mysql://ec2-54-234-71-207.compute-1.amazonaws.com:3306", "admin","Vasthe778!");
		} catch (SQLException e) {
			e.printStackTrace();
			return;
		}
	}

	public static void addDataToDB(Usuario3 datosUsuario) throws SQLException {

		String insertQueryStatement = "INSERT INTO `tablausuarios3`(`busca`, `sexo`, `nombre`, `fechanacimiento`, `provincia`, `localidad`, `foto`, `autodescripcion`, `megusta`, `confidente`, `clave`) VALUES (?,?,?,?,?,?,?,?,?,?,?)";

		stm = conn.prepareStatement(insertQueryStatement);
		stm.setString(1, datosUsuario.getBusca());
		stm.setString(2, datosUsuario.getSexo());
		stm.setString(3, datosUsuario.getNombre());
		stm.setString(4, datosUsuario.getFechanacimiento());
		stm.setString(5, datosUsuario.getProvincia());
		stm.setString(6, datosUsuario.getLocalidad());
		stm.setString(7, datosUsuario.getFoto());
		stm.setString(8, datosUsuario.getAutodescripcion());
		stm.setString(9, datosUsuario.getMegusta());
		stm.setString(10, datosUsuario.getConfidente());
		stm.setString(11, datosUsuario.getClave());
		stm.executeUpdate();
	}  

	public static void addDataByRToDB(BarRestaurante objetoByR) throws SQLException {

		String insertQueryStatement = "INSERT INTO `tablaestablecimientos`(`nombreyemojis`, `frasepublicitaria`, `telefonoydireccion`, `foto`) VALUES (?,?,?,?)";

		stm = conn.prepareStatement(insertQueryStatement);
		stm.setString(1, objetoByR.getNombreyemojis());
		stm.setString(2, objetoByR.getFrasepublicitaria());
		stm.setString(3, objetoByR.getTelefonoydireccion());
		stm.setString(4, objetoByR.getFoto());
		stm.executeUpdate();
	}  
	
	public static Usuario3 getUsuarioById(String ident) {
		Usuario3 usuarioById = null;
		int idInt = 0;
		try {
			idInt = Integer.parseInt(ident);
		} catch (NumberFormatException exception) {
			return usuarioById;
		}
		
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				String clave = rs.getString("clave");
				Usuario3 datosusuario = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente, clave);
				if(id == idInt) { usuarioById = datosusuario; }
			}
//			conn.close();
		} catch (SQLException e) {
			usuarioById = null;
		}
		
		
		return usuarioById;
	}
	
	public static Usuario3 getUsuarioById2(int ident) {
		Usuario3 usuarioById = null;
		
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				String clave = rs.getString("clave");
				Usuario3 datosusuario = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente, clave);
				if(id == ident) { usuarioById = datosusuario; }
			}
//			conn.close();
		} catch (SQLException e) {
			usuarioById = null;
		}
		
		
		return usuarioById;
	}

	public static BarRestaurante getBarRestauranteById(int ident) {
		BarRestaurante barRestaurante = null;
		
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablaestablecimientos";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String nombreyemojis = rs.getString("nombreyemojis");
				String frasepublicitaria = rs.getString("frasepublicitaria");
				String telefonoydireccion = rs.getString("telefonoydireccion");
				String foto = rs.getString("foto");
				BarRestaurante barRestauranteDB = new BarRestaurante(id, nombreyemojis, frasepublicitaria, telefonoydireccion, foto);
				if(id == ident) { barRestaurante = barRestauranteDB; }
			}
//			conn.close();
		} catch (SQLException e) {
			barRestaurante = null;
		}
		
		
		return barRestaurante;
	}

	
	private static int devuelveNumeroMasAlto(List<Integer> listaIds) {
		int devolucion = 0;
		devolucion = Collections.max(listaIds);
		return devolucion;
	}
	
	public static int getLastId() {
		int lastId = 0;
		List<Integer> listaIdentificadores = new ArrayList<Integer>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				listaIdentificadores.add(id);
			}
		lastId = devuelveNumeroMasAlto(listaIdentificadores);

		} catch (SQLException e) {
			lastId = 0;
		}
				
		return lastId;		
	}
	
	public static int getLastIdBarRestaurante() {
		int lastId = 0;
		List<Integer> listaIdentificadores = new ArrayList<Integer>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablaestablecimientos";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				listaIdentificadores.add(id);
			}
		lastId = devuelveNumeroMasAlto(listaIdentificadores);

		} catch (SQLException e) {
			lastId = 0;
		}
				
		return lastId;		
	}

	public static void updateSexoBuscado(String idObjeto, String sexoBuscado) {
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `busca` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, sexoBuscado);
			stm.setString(2, idObjeto);
			stm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			
		}		
	}

		
	public static void updateSexoUsuario(String idObjeto, String sexoUsuario) {
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `sexo` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, sexoUsuario);
			stm.setString(2, idObjeto);
			stm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			
		}		
	}
	
	public static boolean updateNombreUsuario(String idObjeto, String nombreUsuario) {
		boolean numCaractCorrecto = true;
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `nombre` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, nombreUsuario);
			stm.setString(2, idObjeto);
			stm.executeUpdate();
			return numCaractCorrecto;
			
		} catch (SQLException e) {
			numCaractCorrecto = false;
			return numCaractCorrecto;
		}		

	}
	
	public static boolean updateFechaNacimiento(String idObjeto, String fechaNacimiento) {
		boolean formatoFechaCorrecto = true;
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `fechanacimiento` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, fechaNacimiento);
			stm.setString(2, idObjeto);
			stm.executeUpdate();
			return formatoFechaCorrecto;

		} catch (SQLException e) {
				formatoFechaCorrecto = false;
			return formatoFechaCorrecto;
		}		
		
	}
	
	public static void updateProvincia(String idObjeto, String variableProvincia) {
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `provincia` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, variableProvincia);
			stm.setString(2, idObjeto);
			stm.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
			
		}		
		
	}

	public static boolean updateLocalidad(String idObjeto, String localidad) {
		boolean numCaractCorrecto = true;
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `localidad` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, localidad);
			stm.setString(2, idObjeto);
			stm.executeUpdate();
			return numCaractCorrecto;
			
		} catch (SQLException e) {
			numCaractCorrecto = false;
			return numCaractCorrecto;
		}		
	}
	
	public static boolean updateFoto(String idObjeto, String foto) {
		boolean numCaractCorrecto = true;
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `foto` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, foto);
			stm.setString(2, idObjeto);
			stm.executeUpdate();
			return numCaractCorrecto;
			
		} catch (SQLException e) {
			numCaractCorrecto = false;
			return numCaractCorrecto;
		}		
		
	}
	
	public static boolean updateAutodescripcion(String idObjeto, String autodescripcion) {
		boolean numCaractCorrecto = true;
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `autodescripcion` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, autodescripcion);
			stm.setString(2, idObjeto);
			stm.executeUpdate();
			return numCaractCorrecto;
			
		} catch (SQLException e) {
			numCaractCorrecto = false;
			return numCaractCorrecto;
		}		
		
	}

	public static void updateMeGusta(String idEscogedor, String idEscogido) {
		String stringMeGusta = null;
		stringMeGusta = getUsuarioById(idEscogedor).getMegusta();//A este String hay que añadirle, concatenarle, el id de entrada del método.
		stringMeGusta = stringMeGusta.concat("-"+idEscogido);//Este String ahora hay que introducirlo en el campo megusta (actualizar el campo megusta).
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `megusta` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, stringMeGusta);
			stm.setString(2, idEscogedor);
			stm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();			
		}	
	}
	
	public static boolean updateConfidente(String idEscogedor, String idConfidente) {
		boolean existeIdConfidente = true;
		Usuario3 usuario;
		usuario = getUsuarioById(idConfidente);
		if(usuario == null) {existeIdConfidente = false;
			return existeIdConfidente;
		}else {
			try {
				String updateQueryStatement = "UPDATE `tablausuarios3` SET `confidente` = ? WHERE `id` = ?";
				stm = conn.prepareStatement(updateQueryStatement);
				stm.setString(1, idConfidente);
				stm.setString(2, idEscogedor);
				stm.executeUpdate();
				return existeIdConfidente;
				
			} catch (SQLException e) {
				existeIdConfidente = false;
				return existeIdConfidente;
			}
		}
	}
	
	public static void updateConfidenteEnEspera(String idEscogedor) {
		String confidenteEnEspera = "enEspera";
		try {
			String updateQueryStatement = "UPDATE `tablausuarios3` SET `confidente` = ? WHERE `id` = ?";
			stm = conn.prepareStatement(updateQueryStatement);
			stm.setString(1, confidenteEnEspera);
			stm.setString(2, idEscogedor);
			stm.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}	
	
	public static boolean updateClave(String idObjeto, String clave) {
		boolean numCaractCorrecto = true;
		if(clave.length() == 8) {
			try {
				String updateQueryStatement = "UPDATE `tablausuarios3` SET `clave` = ? WHERE `id` = ?";
				stm = conn.prepareStatement(updateQueryStatement);
				stm.setString(1, clave);
				stm.setString(2, idObjeto);
				stm.executeUpdate();
				return numCaractCorrecto;
				
			} catch (SQLException e) {
				numCaractCorrecto = false;
				return numCaractCorrecto;
			}		
		}else {
			numCaractCorrecto = false;
			return numCaractCorrecto;
		}
	}

	
	public static List<Usuario3> getUsuariosHombreBuscaHombre(int idUsuario){
		List<Usuario3> listUsuarFiltroSexoYbusca = new ArrayList<Usuario3>();	
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'hombre' AND busca = 'hombre' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				
				List<String>listaMeGusta =  getMeGusta(idUsuario);

				if(listaMeGusta!=null) {
					//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
					//Si el id ya está en la lista no hay que volver a mostrarlo
					if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
						Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
						listUsuarFiltroSexoYbusca.add(usuario3);
					}
				}else {
					Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
					listUsuarFiltroSexoYbusca.add(usuario3);
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoYbusca = null;
			
		}
		
		return listUsuarFiltroSexoYbusca;
	}
	
	public static List<Usuario3> getUsuariosHombreBuscaMujer(int idUsuario){
		List<Usuario3> listUsuarFiltroSexoYbusca = new ArrayList<Usuario3>();	
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'hombre' AND busca = 'mujer' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				
				List<String>listaMeGusta =  getMeGusta(idUsuario);

				if(listaMeGusta!=null) {
					//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
					//Si el id ya está en la lista no hay que volver a mostrarlo
					if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
						Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
						listUsuarFiltroSexoYbusca.add(usuario3);
					}
				}else {
					Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
					listUsuarFiltroSexoYbusca.add(usuario3);
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoYbusca = null;
			
		}
		
		return listUsuarFiltroSexoYbusca;
	}

	public static List<Usuario3> getUsuariosMujerBuscaHombre(int idUsuario){
		List<Usuario3> listUsuarFiltroSexoYbusca = new ArrayList<Usuario3>();	
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'mujer' AND busca = 'hombre' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				
				List<String>listaMeGusta =  getMeGusta(idUsuario);

				if(listaMeGusta!=null) {
					//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
					//Si el id ya está en la lista no hay que volver a mostrarlo
					if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
						Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
						listUsuarFiltroSexoYbusca.add(usuario3);
					}
				}else {
					Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
					listUsuarFiltroSexoYbusca.add(usuario3);
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoYbusca = null;
			
		}
		
		return listUsuarFiltroSexoYbusca;
	}
	
	public static List<Usuario3> getUsuariosMujerBuscaMujer(int idUsuario){
		List<Usuario3> listUsuarFiltroSexoYbusca = new ArrayList<Usuario3>();	
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'mujer' AND busca = 'mujer' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				
				List<String>listaMeGusta =  getMeGusta(idUsuario);

				if(listaMeGusta!=null) {
					if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
						Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
						listUsuarFiltroSexoYbusca.add(usuario3);
					}
				}else {
					Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);				
					listUsuarFiltroSexoYbusca.add(usuario3);
				}
				
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoYbusca = null;
			
		}
		
		return listUsuarFiltroSexoYbusca;
	}
	
	public static List<Usuario3> getUsuariosHombreBuscaHombreByEdad(int limiteSup, int limiteInf, int idUsuario){
		List<Usuario3> listUsuarFiltroSexoBuscaYedad = new ArrayList<Usuario3>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'hombre' AND busca = 'hombre' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);
				int edadUsuario3 = MetodosAuxiliares.metodoCalcularEdad2(usuario3);
				if(edadUsuario3 <= limiteSup && edadUsuario3 >= limiteInf) {
					List<String>listaMeGusta =  getMeGusta(idUsuario);

					if(listaMeGusta!=null) {
						//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
						//Si el id ya está en la lista no hay que volver a mostrarlo
						if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
							listUsuarFiltroSexoBuscaYedad.add(usuario3);
						}
					}else {
						listUsuarFiltroSexoBuscaYedad.add(usuario3);
					}
					
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoBuscaYedad = null;

		}
		
		return listUsuarFiltroSexoBuscaYedad;
	}
	
	public static List<Usuario3> getUsuariosHombreBuscaMujerByEdad(int limitSup, int limitInf, int idUsuario){
		List<Usuario3> listUsuarFiltroSexoBuscaYedad = new ArrayList<Usuario3>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'hombre' AND busca = 'mujer' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);
				int edadUsuario3 = MetodosAuxiliares.metodoCalcularEdad2(usuario3);
				if(edadUsuario3 <= limitSup && edadUsuario3 >= limitInf) {
					List<String>listaMeGusta =  getMeGusta(idUsuario);

					if(listaMeGusta!=null) {
						//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
						//Si el id ya está en la lista no hay que volver a mostrarlo
						if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
							listUsuarFiltroSexoBuscaYedad.add(usuario3);
						}
					}else {
						listUsuarFiltroSexoBuscaYedad.add(usuario3);
					}
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoBuscaYedad = null;

		}
		
		return listUsuarFiltroSexoBuscaYedad;
	}

	
	public static List<Usuario3> getUsuariosMujerBuscaHombreByEdad(int limitSup, int limitInf, int idUsuario){
		List<Usuario3> listUsuarFiltroSexoBuscaYedad = new ArrayList<Usuario3>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'mujer' AND busca = 'hombre' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);
				int edadUsuario3 = MetodosAuxiliares.metodoCalcularEdad2(usuario3);
				if(edadUsuario3 <= limitSup && edadUsuario3 >= limitInf) {
					List<String>listaMeGusta =  getMeGusta(idUsuario);

					if(listaMeGusta!=null) {
						//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
						//Si el id ya está en la lista no hay que volver a mostrarlo
						if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
							listUsuarFiltroSexoBuscaYedad.add(usuario3);
						}
					}else {
						listUsuarFiltroSexoBuscaYedad.add(usuario3);
					}
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoBuscaYedad = null;
			
		}
		
		return listUsuarFiltroSexoBuscaYedad;
	}

	public static List<Usuario3> getUsuariosMujerBuscaMujerByEdad(int limitSup, int limitInf, int idUsuario){
		List<Usuario3> listUsuarFiltroSexoYedad = new ArrayList<Usuario3>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3 WHERE sexo = 'mujer' AND busca = 'mujer' AND id!=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);
			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				Usuario3 usuario3 = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente);
				int edadUsuario3 = MetodosAuxiliares.metodoCalcularEdad2(usuario3);
				if(edadUsuario3 <= limitSup && edadUsuario3 >= limitInf) {
					List<String>listaMeGusta =  getMeGusta(idUsuario);

					if(listaMeGusta!=null) {
						//Si el id obtenido con la consulta no está en la lista --> todavía no ha dado "me gusta" a ese usuario --> le saldrá en la lista
						//Si el id ya está en la lista no hay que volver a mostrarlo
						if (listaMeGusta.indexOf(String.valueOf(id)) == -1) {
							listUsuarFiltroSexoYedad.add(usuario3);
						}
					}else {
						listUsuarFiltroSexoYedad.add(usuario3);
					}
				}
			}
//			conn.close();

		} catch (SQLException e) {
			listUsuarFiltroSexoYedad = null;
			
		}
		
		return listUsuarFiltroSexoYedad;
	}

	public static List<BarRestaurante> getBaresYrestaurantes(){
		List<BarRestaurante> listBaresYrestaurantes = new ArrayList<BarRestaurante>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablaestablecimientos";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String nombreyemojis = rs.getString("nombreyemojis");
				String frasepublicitaria = rs.getString("frasepublicitaria");
				String telefonoydireccion = rs.getString("telefonoydireccion");
				String foto = rs.getString("foto");
				BarRestaurante barRestaurante = new BarRestaurante(id, nombreyemojis, frasepublicitaria, telefonoydireccion, foto);
					listBaresYrestaurantes.add(barRestaurante);
			}
//			conn.close();

		} catch (SQLException e) {
			listBaresYrestaurantes = null;
			
		}
		
		return listBaresYrestaurantes;
	}
	
	public static boolean verificaClave(String identificador, String claveIntroducida) {
		boolean verificacion = false;
		if(!existeId(identificador)) { return verificacion;}
		String claveRecuperada;
		claveRecuperada = getUsuarioById(identificador).getClave();
		if(claveRecuperada.equals(claveIntroducida)) {
			verificacion = true;
		}else {
			verificacion = false;
		}
		
		return verificacion;
	}

	public static boolean existeId(String identificador) {
		boolean existeIdent = false;
		Usuario3 objetoUsuario;
		int idInt = 0;
		try {
			idInt = Integer.parseInt(identificador);
		} catch (NumberFormatException exception) {
			return existeIdent;
		}

		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				objetoUsuario = new Usuario3(id);
				if(id == idInt) { existeIdent = true;
						return existeIdent;}					
			}
//			conn.close();

		} catch (SQLException e) {			
			existeIdent = false;			
		}
		
		return existeIdent;			
	}
	
	public static void addMensajeToDB(Mensaje datosMensaje) throws SQLException {

		String insertQueryStatement = "INSERT INTO `mensajes`(`idEmisor`, `idReceptor`, `mensaje`) VALUES (?,?,?)";

		stm = conn.prepareStatement(insertQueryStatement);
		stm.setInt(1, datosMensaje.getIdEmisor());
		stm.setInt(2, datosMensaje.getIdReceptor());
		stm.setString(3, datosMensaje.getMensaje());
		
	
		stm.executeUpdate();
	}  
	
	
	
	public static List<Mensaje> getMensajes(int idUsuario, int idUsuarioActual) {
		List<Mensaje> mensajes = new ArrayList<Mensaje>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM mensajes WHERE (idEmisor = ? OR idReceptor = ?) AND "
					+ "(idEmisor = ? OR idReceptor = ?) ORDER BY fechaHora";
			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);
			stm.setInt(2, idUsuario);
			stm.setInt(3, idUsuarioActual);
			stm.setInt(4, idUsuarioActual);
			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				int idEmisor = rs.getInt("idEmisor");
				int idReceptor = rs.getInt("idReceptor");
				String mensaje = rs.getString("mensaje");
				String fechaHora = rs.getString("fechaHora");
				
				Mensaje m = new Mensaje(id, idEmisor, idReceptor, mensaje, fechaHora);
				mensajes.add(m);
			}
			// conn.close();
		} catch (SQLException e) {
			mensajes = null;

		}

		return mensajes;
	}
	
	//Método auxiliar del método getListaUsuariosChateo.
	public static List<Mensaje> getMensajesDeUnUsuarioComoEmisorOreceptor(int idUsuario) {
		makeJDBCConnection();
		List<Mensaje> mensajes = new ArrayList<Mensaje>();
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM mensajes WHERE (idEmisor = ? OR idReceptor = ?)";
			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);
			stm.setInt(2, idUsuario);

			ResultSet rs = stm.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				int idEmisor = rs.getInt("idEmisor");
				int idReceptor = rs.getInt("idReceptor");
				String mensaje = rs.getString("mensaje");
				String fechaHora = rs.getString("fechaHora");
				Mensaje m = new Mensaje(id, idEmisor, idReceptor, mensaje, fechaHora);
				mensajes.add(m);
			}
			// conn.close();
		} catch (SQLException e) {
			mensajes = null;

		}

		return mensajes;
	}

	// Este método devolvería una lista de usuarios que serían los usuarios que han
	// tenido chat con el usuario que se introduce (su id) en el parámetro de
	// entrada del método.
	public static List<Usuario3> getListaUsuariosChateo(int idUsuario) {
		List<Integer> listaId = new ArrayList<Integer>();
		List<Integer> listaIdSinRepeticiones = new ArrayList<Integer>();
		List<Mensaje> listaMensajesUsuarioComoEmisorOreceptor = getMensajesDeUnUsuarioComoEmisorOreceptor(idUsuario);
		for (Mensaje mensaje : listaMensajesUsuarioComoEmisorOreceptor) {
			if (mensaje.getIdEmisor() != idUsuario) {
				listaId.add(mensaje.getIdEmisor());
			} else {
			}
			if (mensaje.getIdReceptor() != idUsuario) {
				listaId.add(mensaje.getIdReceptor());
			} else {
			}
		}
		Set<Integer> set = new HashSet<Integer>(listaId);
		listaIdSinRepeticiones.addAll(set);
		Usuario3 usuario;
		List<Usuario3> listaUsuariosChat = new ArrayList<Usuario3>();
		for (Integer id : listaIdSinRepeticiones) {
			usuario = getUsuarioById2(id);
			listaUsuariosChat.add(usuario);
		}
		return listaUsuariosChat;
	}
	
	
	//Comprueba si existe chat entre dos usuarios
	public static boolean existeChat(int idUsuario1, int idUsuario2) {
		
		boolean existe=false;
		int id = 0; 
		
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT COUNT(*) AS numero FROM mensajes WHERE (idEmisor = ? OR idReceptor = ?) AND (idEmisor = ? OR idReceptor = ?)";
			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario1);
			stm.setInt(2, idUsuario1);
			stm.setInt(3, idUsuario2);
			stm.setInt(4, idUsuario2);
			
			ResultSet rs = stm.executeQuery();
			
			while (rs.next()) {
				id = rs.getInt("numero");
			}
			// conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		if (id!=0) {
			existe=true;
		}
		
		return existe;
	}
	
	
	//Devuelve los megusta del usuario con el id "idUsuario" en una lista
	public static List<String> getMeGusta(int idUsuario){
		List<String> listaMeGusta = null;	
		
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT megusta FROM tablausuarios3 WHERE id=?";

			stm = conn.prepareStatement(getQueryStatement);
			stm.setInt(1, idUsuario);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				String megusta = rs.getString("megusta");
				
				if(megusta!=null && megusta.length()!=1) { 
					megusta=megusta.substring(1); 
					
					String[] lista = megusta.split("-");
					listaMeGusta =  new ArrayList<String> (Arrays.asList(lista));
				}
				
			}
//			conn.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return listaMeGusta;
	}

	public static List<Usuario3> buscaMatchesDeUsuario(String idUsuarioIniciaSesion) {//Devuelve todos los usuarios con los que hizo match uno dado cuyo id es el que se introduce en 
		List<Usuario3> listaUsuariosMatch = new ArrayList<Usuario3>();				//el parámetro de entrada del método.
		try {
			// MySQL Select Query Tutorial
			String getQueryStatement = "SELECT * FROM tablausuarios3";

			stm = conn.prepareStatement(getQueryStatement);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String busca = rs.getString("busca");
				String sexo = rs.getString("sexo");
				String nombre = rs.getString("nombre");
				String fechanacimiento = rs.getString("fechanacimiento");
				String provincia = rs.getString("provincia");
				String localidad = rs.getString("localidad");
				String foto = rs.getString("foto");
				String autodescripcion = rs.getString("autodescripcion");
				String megusta = rs.getString("megusta");
				String confidente = rs.getString("confidente");
				String clave = rs.getString("clave");
				Usuario3 datosusuario = new Usuario3(id, busca, sexo, nombre, fechanacimiento, provincia, localidad, foto, autodescripcion, megusta, confidente, clave);
				if(megusta.contains(idUsuarioIniciaSesion) && getUsuarioById(idUsuarioIniciaSesion).getMegusta().contains(Integer.toString(datosusuario.getId()))) {					
					listaUsuariosMatch.add(datosusuario);
				}
			}
//			conn.close();
		} catch (SQLException e) {
			listaUsuariosMatch = null;
		}

		return listaUsuariosMatch;

	}
}
