package inicioSesionConPerfilYaCreado;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import metodosDatasource.MetodosDatasource;

public class ActualizarPerfilServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ActualizarPerfilServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString = request.getParameter("idString");
		if(MetodosDatasource.getUsuarioById(idString).getBusca().equals("hombre") && MetodosDatasource.getUsuarioById(idString).getSexo().equals("mujer")) {
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("IDSTRING", idString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/actualizarPerfilMujerHetero.jsp");
	        dispatcher.forward(request, response);
		}else {
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("IDSTRING", idString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/actualizarPerfil.jsp");
	        dispatcher.forward(request, response);
		}
	}

}
