package inicioSesionConPerfilYaCreado;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import metodosDatasource.MetodosDatasource;

public class UpdateConfidenteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public UpdateConfidenteServlet() {
        super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String idString = request.getParameter("idString");
		String idConfidente = request.getParameter("idConfidente");
		boolean existeIdConfidente = false;
		existeIdConfidente = MetodosDatasource.updateConfidente(idString, idConfidente);
		if(existeIdConfidente) {
			HttpSession httpSession = request.getSession();
			httpSession.setAttribute("IDSTRING", idString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/volverAactualizarObuscar.jsp");
			dispatcher.forward(request, response);
		}else {
			HttpSession httpSesion = request.getSession();
			httpSesion.setAttribute("IDSTRING", idString);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/updateconfidenteSQLException.jsp");
			dispatcher.forward(request, response);
		}

	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher("/updateconfidenteSQLException.jsp");
        dispatcher.forward(request, response);

	}

}
